package com.app.wastemanagementforkids.game;

public class GameItem {
    String question, link[];
    int v;

    public GameItem() {
        this.question = question;
        this.link = link;
        this.v = v;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String[] getLink() {
        return link;
    }

    public void setLink(String[] link) {
        this.link = link;
    }

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }
}
